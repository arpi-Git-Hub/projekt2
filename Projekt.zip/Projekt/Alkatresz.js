let alkatreszek=["ASUS ROG CROSSHAIR VIII EXTREME","GIGABYTE B650E AORUS MASTER","Gigabyte B550 GAMING X alaplap","Asrock B450M-HDV R4.0 AMD B450 AM4 foglalat Micro ATX","Intel Processzor - Core i5-13600K BOX No Cooler","Intel cpu s1700 core i7-12700k 3.6ghz 25mb cache box BX8071512700K","AMD Ryzen 5 5600X processzor 3,7 GHz 32 MB L3 Doboz","AMD Ryzen 7 5700G processzor 3,8 GHz 16 MB L3 Doboz"]
let ertekeles=[0,0,0,0,0]
let aktualis=-1;

for (let i=0; i<termekek.length;i++)
{
    document.getElementById("menu").innerHTML+=<li><button class="dropdown-item" type="button" onclick="Valasztas(${i})">${alkatreszek[i]}</button></li>
}

Valasztas(0)

function Valasztas(x)
{
    aktualis=x;
    document.getElementById("kiiras").innerHTML=<h1>${alkatreszek[x]}</h1>
    if (ertekeles[x]!=0)
    {
        Csillagkiir(ertekeles[aktualis])   
    }
    else
    {
        document.getElementById("csillag").innerHTML="Még nincs értékelve!"
    }
}

function Ertekeles()
{
    y=Number(document.getElementById("star").value)
    Csillagkiir(y)
    ertekeles[aktualis]=y
}

function Csillagkiir()
{
    document.getElementById("csillag").innerHTML="" z = '<img src="csillag.jpg">'
    for (let i=0;i<x;i++)
    {
        document.getElementById("csillag").innerHTML +=z
    }
}
